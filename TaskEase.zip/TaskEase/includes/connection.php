<?php
    $connection = mysqli_connect("localhost","root","root");
    //$db = mysqli_select_db($connection,"tms_db");
$db = mysqli_select_db($connection,"TaskEase");

?>